a = 123 +456
print(a)